<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Update these to match the form fields
    $firstName = $_POST['firstname'] ?? '';
    $lastName = $_POST['lastname'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmpassword = $_POST['confirm_password'] ?? '';
    $number = $_POST['phone'] ?? '';

    // Validate form data
    if (empty($firstName) || empty($lastName) || empty($email) || empty($password) || empty($confirmpassword) || empty($number)) {
        die("All fields are required!");
    }

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'test');
    if ($conn->connect_error) {
        die('Connection Failed: ' . $conn->connect_error);
    } else {
        // Prepare SQL statement
        $stmt = $conn->prepare("INSERT INTO registration (firstName, lastName, email, password, confirmPassword, phoneNumber) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssi", $firstName, $lastName, $email, $password, $confirmpassword, $number);

        if ($stmt->execute()) {
            echo "Registration successful!";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
}
?>
